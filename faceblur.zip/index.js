const { S3Client, GetObjectCommand, PutObjectCommand } = require('@aws-sdk/client-s3');
const { RekognitionClient, DetectFacesCommand } = require('@aws-sdk/client-rekognition');
const Jimp = require('jimp');

const rekognition = new RekognitionClient({ region: "us-east-1" });
const s3na = new S3Client({ region: "us-east-1" });
const s3sa = new S3Client({ region: "sa-east-1" });

const srcBucket = "beon-na";
const destBucket = "beon-sa";

/**
 * Função Lambda para aplicar efeito blur em rostos detectados em imagens recebidas no bucket S3.
 * @param {Object} event - Evento da Lambda que aciona a função. Deve conter informações sobre o objeto criado no S3.
 * @returns {Promise<Buffer>} - Retorna um buffer da imagem borrada.
 */
exports.handler = async (event) => {
  try {
    let srcKey;
    if (event.Records && event.Records.length > 0) {
      srcKey = event.Records[0].s3.object.key;
    }

    if (!srcKey) {
      throw new Error("Nenhum registro recebido para leitura.");
    }

    const response = await downloadImage(srcKey);
    const faceDetails = await detectFaces(response);
    const buffer = await blurFaces(response.Body, faceDetails);
    // const uploadSucess = await uploadImage(buffer, srcKey)
    return buffer;
  } catch (error) {
    console.error(error);
    throw error;
  }
};

/**
 * Baixa a imagem do S3.
 * @param {string} srcKey - Chave do objeto no S3.
 * @returns {Promise<{Body: Buffer}>} - Retorna um objeto contendo o buffer da imagem.
 */
const downloadImage = async (srcKey) => {
  const command = new GetObjectCommand({
    Bucket: srcBucket,
    Key: srcKey
  });

  try {
    const response = await s3na.send(command);
    const body = await streamToBuffer(response.Body);
    return { Body: body };
  } catch (error) {
    throw error;
  }
};

/**
 * Detecta os rostos na imagem usando Rekognition.
 * @param {Object} response - Resposta do download da imagem.
 * @returns {Promise<Array>} - Retorna um array de detalhes dos rostos detectados.
 */
const detectFaces = async (response) => {
  const params = {
    Image: { Bytes: response.Body }, // Passando os bytes da imagem para o Rekognition
    Attributes: ['DEFAULT']
  };
  const command = new DetectFacesCommand(params);

  try {
    const data = await rekognition.send(command);
    return data.FaceDetails;
  } catch (error) {
    throw error;
  }
};

/**
 * Aplica o efeito de blur nos rostos detectados na imagem.
 * @param {Buffer} imageBuffer - Buffer da imagem.
 * @param {Array} faceDetails - Detalhes dos rostos detectados.
 * @returns {Promise<Buffer>} - Retorna um buffer da imagem borrada.
 */
const blurFaces = async (imageBuffer, faceDetails) => {
  try {
    const image = await Jimp.read(imageBuffer);
    const metadata = image.bitmap;

    faceDetails.forEach(faceDetail => {
      const box = faceDetail.BoundingBox;
      const left = Math.floor(box.Left * metadata.width);
      const top = Math.floor(box.Top * metadata.height);
      const width = Math.floor(box.Width * metadata.width);
      const height = Math.floor(box.Height * metadata.height);

      image.crop(left, top, width, height).blur(30); // Ajuste o valor de acordo com o nível de desfoque desejado
    });

    // Salvar a imagem resultante em um buffer
    const buffer = await image.getBufferAsync(Jimp.MIME_JPEG);
    return buffer;
  } catch (error) {
    throw error;
  }
};

/**
 * Faz o upload da imagem borrada para o bucket S3 de destino.
 * @param {Buffer} buffer - Buffer da imagem borrada.
 * @param {string} srcKey - Chave do objeto no S3.
 * @returns {Promise<void>}
 */
const uploadImage = async (buffer, srcKey) => {
  const command = new PutObjectCommand({
    Bucket: destBucket,
    Key: srcKey,
    Body: buffer,
    ContentType: "image/jpeg", // Assumindo que as imagens são JPEG
    ACL: 'public-read'
  });

  try {
    await s3sa.send(command);
  } catch (error) {
    throw error;
  }
};

/**
 * Converte um stream em um buffer.
 * @param {stream.Readable} stream - Stream a ser convertido.
 * @returns {Promise<Buffer>} - Retorna um buffer.
 */
const streamToBuffer = async (stream) => {
  const chunks = [];
  for await (const chunk of stream) {
    chunks.push(chunk);
  }
  return Buffer.concat(chunks);
};
